namespace RTadeusiewicz.NN.Example08a
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.wyjscie10 = new System.Windows.Forms.TextBox();
            this.wejscie10 = new System.Windows.Forms.TextBox();
            this.Wejscie = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.wejscie00 = new System.Windows.Forms.MaskedTextBox();
            this.wejscie01 = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BIAS = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.waga112 = new System.Windows.Forms.MaskedTextBox();
            this.waga110 = new System.Windows.Forms.MaskedTextBox();
            this.waga100 = new System.Windows.Forms.MaskedTextBox();
            this.waga102 = new System.Windows.Forms.MaskedTextBox();
            this.waga101 = new System.Windows.Forms.MaskedTextBox();
            this.waga111 = new System.Windows.Forms.MaskedTextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.waga212 = new System.Windows.Forms.MaskedTextBox();
            this.waga210 = new System.Windows.Forms.MaskedTextBox();
            this.waga200 = new System.Windows.Forms.MaskedTextBox();
            this.waga202 = new System.Windows.Forms.MaskedTextBox();
            this.waga201 = new System.Windows.Forms.MaskedTextBox();
            this.waga211 = new System.Windows.Forms.MaskedTextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.wyjscie21 = new System.Windows.Forms.TextBox();
            this.wejscie21 = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.wyjscie20 = new System.Windows.Forms.TextBox();
            this.wejscie20 = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.wyjscie11 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.wejscie11 = new System.Windows.Forms.TextBox();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.wyjscie23 = new System.Windows.Forms.TextBox();
            this.wyjscie22 = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.wyjscie10);
            this.groupBox1.Controls.Add(this.wejscie10);
            this.groupBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(22, 164);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(260, 79);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Neuron (1,1)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(82, 48);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Output";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(93, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Sum";
            // 
            // wyjscie10
            // 
            this.wyjscie10.BackColor = System.Drawing.Color.LightGray;
            this.wyjscie10.Cursor = System.Windows.Forms.Cursors.No;
            this.wyjscie10.Location = new System.Drawing.Point(131, 45);
            this.wyjscie10.Name = "wyjscie10";
            this.wyjscie10.ReadOnly = true;
            this.wyjscie10.Size = new System.Drawing.Size(45, 20);
            this.wyjscie10.TabIndex = 6;
            this.wyjscie10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // wejscie10
            // 
            this.wejscie10.BackColor = System.Drawing.Color.LightGray;
            this.wejscie10.Cursor = System.Windows.Forms.Cursors.No;
            this.wejscie10.ForeColor = System.Drawing.SystemColors.WindowText;
            this.wejscie10.Location = new System.Drawing.Point(131, 19);
            this.wejscie10.Name = "wejscie10";
            this.wejscie10.ReadOnly = true;
            this.wejscie10.Size = new System.Drawing.Size(45, 20);
            this.wejscie10.TabIndex = 5;
            this.wejscie10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Wejscie
            // 
            this.Wejscie.AutoSize = true;
            this.Wejscie.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Wejscie.Location = new System.Drawing.Point(67, 24);
            this.Wejscie.Name = "Wejscie";
            this.Wejscie.Size = new System.Drawing.Size(54, 13);
            this.Wejscie.TabIndex = 4;
            this.Wejscie.Text = "input (1,1)";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.wejscie00);
            this.groupBox3.Controls.Add(this.wejscie01);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.Wejscie);
            this.groupBox3.Cursor = System.Windows.Forms.Cursors.Default;
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox3.Location = new System.Drawing.Point(22, 10);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(697, 52);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Input";
            // 
            // wejscie00
            // 
            this.wejscie00.Location = new System.Drawing.Point(131, 21);
            this.wejscie00.Name = "wejscie00";
            this.wejscie00.Size = new System.Drawing.Size(45, 20);
            this.wejscie00.TabIndex = 9;
            this.wejscie00.Text = "1,000";
            this.wejscie00.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // wejscie01
            // 
            this.wejscie01.Location = new System.Drawing.Point(441, 24);
            this.wejscie01.Name = "wejscie01";
            this.wejscie01.Size = new System.Drawing.Size(45, 20);
            this.wejscie01.TabIndex = 8;
            this.wejscie01.Text = "2,000";
            this.wejscie01.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(380, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "input (1,2)";
            // 
            // BIAS
            // 
            this.BIAS.Location = new System.Drawing.Point(654, 194);
            this.BIAS.Name = "BIAS";
            this.BIAS.ReadOnly = true;
            this.BIAS.Size = new System.Drawing.Size(45, 20);
            this.BIAS.TabIndex = 10;
            this.BIAS.Text = "-1,000";
            this.BIAS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(610, 197);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "BIAS";
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.Transparent;
            this.groupBox6.Controls.Add(this.waga112);
            this.groupBox6.Controls.Add(this.waga110);
            this.groupBox6.Controls.Add(this.waga100);
            this.groupBox6.Controls.Add(this.waga102);
            this.groupBox6.Controls.Add(this.waga101);
            this.groupBox6.Controls.Add(this.waga111);
            this.groupBox6.Cursor = System.Windows.Forms.Cursors.Default;
            this.groupBox6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox6.Location = new System.Drawing.Point(22, 89);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(697, 52);
            this.groupBox6.TabIndex = 11;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Weights";
            // 
            // waga112
            // 
            this.waga112.Location = new System.Drawing.Point(526, 19);
            this.waga112.Name = "waga112";
            this.waga112.Size = new System.Drawing.Size(42, 20);
            this.waga112.TabIndex = 13;
            this.waga112.Text = "6,000";
            this.waga112.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // waga110
            // 
            this.waga110.Location = new System.Drawing.Point(362, 19);
            this.waga110.Name = "waga110";
            this.waga110.Size = new System.Drawing.Size(45, 20);
            this.waga110.TabIndex = 12;
            this.waga110.Text = "2,000";
            this.waga110.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // waga100
            // 
            this.waga100.Location = new System.Drawing.Point(46, 19);
            this.waga100.Name = "waga100";
            this.waga100.Size = new System.Drawing.Size(45, 20);
            this.waga100.TabIndex = 11;
            this.waga100.Text = "1,000";
            this.waga100.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // waga102
            // 
            this.waga102.Location = new System.Drawing.Point(216, 19);
            this.waga102.Name = "waga102";
            this.waga102.Size = new System.Drawing.Size(45, 20);
            this.waga102.TabIndex = 10;
            this.waga102.Text = "5,000";
            this.waga102.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // waga101
            // 
            this.waga101.Location = new System.Drawing.Point(131, 19);
            this.waga101.Name = "waga101";
            this.waga101.Size = new System.Drawing.Size(45, 20);
            this.waga101.TabIndex = 9;
            this.waga101.Text = "3,000";
            this.waga101.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // waga111
            // 
            this.waga111.Location = new System.Drawing.Point(444, 19);
            this.waga111.Name = "waga111";
            this.waga111.Size = new System.Drawing.Size(45, 20);
            this.waga111.TabIndex = 8;
            this.waga111.Text = "4,000";
            this.waga111.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.Transparent;
            this.groupBox7.Controls.Add(this.waga212);
            this.groupBox7.Controls.Add(this.waga210);
            this.groupBox7.Controls.Add(this.waga200);
            this.groupBox7.Controls.Add(this.waga202);
            this.groupBox7.Controls.Add(this.waga201);
            this.groupBox7.Controls.Add(this.waga211);
            this.groupBox7.Cursor = System.Windows.Forms.Cursors.Default;
            this.groupBox7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox7.Location = new System.Drawing.Point(22, 268);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(697, 52);
            this.groupBox7.TabIndex = 14;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Weights";
            // 
            // waga212
            // 
            this.waga212.Location = new System.Drawing.Point(526, 19);
            this.waga212.Name = "waga212";
            this.waga212.Size = new System.Drawing.Size(42, 20);
            this.waga212.TabIndex = 13;
            this.waga212.Text = "2,000";
            this.waga212.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // waga210
            // 
            this.waga210.Location = new System.Drawing.Point(362, 19);
            this.waga210.Name = "waga210";
            this.waga210.Size = new System.Drawing.Size(45, 20);
            this.waga210.TabIndex = 12;
            this.waga210.Text = "1,000";
            this.waga210.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // waga200
            // 
            this.waga200.Location = new System.Drawing.Point(46, 19);
            this.waga200.Name = "waga200";
            this.waga200.Size = new System.Drawing.Size(45, 20);
            this.waga200.TabIndex = 11;
            this.waga200.Text = "1,000";
            this.waga200.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // waga202
            // 
            this.waga202.Location = new System.Drawing.Point(216, 19);
            this.waga202.Name = "waga202";
            this.waga202.Size = new System.Drawing.Size(45, 20);
            this.waga202.TabIndex = 10;
            this.waga202.Text = "1,000";
            this.waga202.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // waga201
            // 
            this.waga201.Location = new System.Drawing.Point(131, 19);
            this.waga201.Name = "waga201";
            this.waga201.Size = new System.Drawing.Size(45, 20);
            this.waga201.TabIndex = 9;
            this.waga201.Text = "1,000";
            this.waga201.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // waga211
            // 
            this.waga211.Location = new System.Drawing.Point(444, 19);
            this.waga211.Name = "waga211";
            this.waga211.Size = new System.Drawing.Size(45, 20);
            this.waga211.TabIndex = 8;
            this.waga211.Text = "1,000";
            this.waga211.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.wyjscie21);
            this.groupBox2.Controls.Add(this.wejscie21);
            this.groupBox2.Cursor = System.Windows.Forms.Cursors.Default;
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox2.Location = new System.Drawing.Point(384, 349);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(208, 79);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Neuron (2,2)";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(68, 48);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(39, 13);
            this.label11.TabIndex = 14;
            this.label11.Text = "Output";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(79, 18);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(28, 13);
            this.label9.TabIndex = 14;
            this.label9.Text = "Sum";
            // 
            // wyjscie21
            // 
            this.wyjscie21.BackColor = System.Drawing.Color.LightGray;
            this.wyjscie21.Cursor = System.Windows.Forms.Cursors.No;
            this.wyjscie21.Location = new System.Drawing.Point(118, 45);
            this.wyjscie21.Name = "wyjscie21";
            this.wyjscie21.ReadOnly = true;
            this.wyjscie21.Size = new System.Drawing.Size(45, 20);
            this.wyjscie21.TabIndex = 6;
            this.wyjscie21.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // wejscie21
            // 
            this.wejscie21.BackColor = System.Drawing.Color.LightGray;
            this.wejscie21.Cursor = System.Windows.Forms.Cursors.No;
            this.wejscie21.Location = new System.Drawing.Point(118, 15);
            this.wejscie21.Name = "wejscie21";
            this.wejscie21.ReadOnly = true;
            this.wejscie21.Size = new System.Drawing.Size(45, 20);
            this.wejscie21.TabIndex = 5;
            this.wejscie21.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Transparent;
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.wyjscie20);
            this.groupBox4.Controls.Add(this.wejscie20);
            this.groupBox4.Cursor = System.Windows.Forms.Cursors.Default;
            this.groupBox4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox4.Location = new System.Drawing.Point(24, 349);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(260, 79);
            this.groupBox4.TabIndex = 7;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Neuron (2,1)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(82, 48);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(39, 13);
            this.label10.TabIndex = 13;
            this.label10.Text = "Output";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(93, 26);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(28, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Sum";
            // 
            // wyjscie20
            // 
            this.wyjscie20.BackColor = System.Drawing.Color.LightGray;
            this.wyjscie20.Cursor = System.Windows.Forms.Cursors.No;
            this.wyjscie20.Location = new System.Drawing.Point(131, 45);
            this.wyjscie20.Name = "wyjscie20";
            this.wyjscie20.ReadOnly = true;
            this.wyjscie20.Size = new System.Drawing.Size(45, 20);
            this.wyjscie20.TabIndex = 6;
            this.wyjscie20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // wejscie20
            // 
            this.wejscie20.BackColor = System.Drawing.Color.LightGray;
            this.wejscie20.Cursor = System.Windows.Forms.Cursors.No;
            this.wejscie20.Location = new System.Drawing.Point(131, 19);
            this.wejscie20.Name = "wejscie20";
            this.wejscie20.ReadOnly = true;
            this.wejscie20.Size = new System.Drawing.Size(45, 20);
            this.wejscie20.TabIndex = 5;
            this.wejscie20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.Transparent;
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.wyjscie11);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.wejscie11);
            this.groupBox5.Cursor = System.Windows.Forms.Cursors.Default;
            this.groupBox5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox5.Location = new System.Drawing.Point(384, 164);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(208, 79);
            this.groupBox5.TabIndex = 7;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Neuron (1,2)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(66, 48);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Output";
            // 
            // wyjscie11
            // 
            this.wyjscie11.BackColor = System.Drawing.Color.LightGray;
            this.wyjscie11.Cursor = System.Windows.Forms.Cursors.No;
            this.wyjscie11.Location = new System.Drawing.Point(116, 45);
            this.wyjscie11.Name = "wyjscie11";
            this.wyjscie11.ReadOnly = true;
            this.wyjscie11.Size = new System.Drawing.Size(45, 20);
            this.wyjscie11.TabIndex = 6;
            this.wyjscie11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(77, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Sum";
            // 
            // wejscie11
            // 
            this.wejscie11.BackColor = System.Drawing.Color.LightGray;
            this.wejscie11.Cursor = System.Windows.Forms.Cursors.No;
            this.wejscie11.Location = new System.Drawing.Point(116, 19);
            this.wejscie11.Name = "wejscie11";
            this.wejscie11.ReadOnly = true;
            this.wejscie11.Size = new System.Drawing.Size(45, 20);
            this.wejscie11.TabIndex = 5;
            this.wejscie11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(647, 378);
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.ReadOnly = true;
            this.maskedTextBox1.Size = new System.Drawing.Size(45, 20);
            this.maskedTextBox1.TabIndex = 12;
            this.maskedTextBox1.Text = "-1,000";
            this.maskedTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(604, 380);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "BIAS";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button2.Location = new System.Drawing.Point(563, 518);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(155, 30);
            this.button2.TabIndex = 15;
            this.button2.Text = "Calculate";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.Transparent;
            this.groupBox8.Controls.Add(this.label13);
            this.groupBox8.Controls.Add(this.label12);
            this.groupBox8.Controls.Add(this.wyjscie23);
            this.groupBox8.Controls.Add(this.wyjscie22);
            this.groupBox8.Cursor = System.Windows.Forms.Cursors.Default;
            this.groupBox8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox8.Location = new System.Drawing.Point(22, 445);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(697, 52);
            this.groupBox8.TabIndex = 10;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Output";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(405, 21);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(63, 13);
            this.label13.TabIndex = 16;
            this.label13.Text = "Output (2,2)";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(60, 22);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 13);
            this.label12.TabIndex = 15;
            this.label12.Text = "Output (2,1)";
            // 
            // wyjscie23
            // 
            this.wyjscie23.BackColor = System.Drawing.Color.LightGray;
            this.wyjscie23.Cursor = System.Windows.Forms.Cursors.No;
            this.wyjscie23.Location = new System.Drawing.Point(479, 18);
            this.wyjscie23.Name = "wyjscie23";
            this.wyjscie23.ReadOnly = true;
            this.wyjscie23.Size = new System.Drawing.Size(45, 20);
            this.wyjscie23.TabIndex = 15;
            this.wyjscie23.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // wyjscie22
            // 
            this.wyjscie22.BackColor = System.Drawing.Color.LightGray;
            this.wyjscie22.Cursor = System.Windows.Forms.Cursors.No;
            this.wyjscie22.Location = new System.Drawing.Point(133, 19);
            this.wyjscie22.Name = "wyjscie22";
            this.wyjscie22.ReadOnly = true;
            this.wyjscie22.Size = new System.Drawing.Size(45, 20);
            this.wyjscie22.TabIndex = 14;
            this.wyjscie22.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(728, 561);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.BIAS);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.maskedTextBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Name = "MainForm";
            this.Text = "Backpropagation (Example08a)";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label Wejscie;
        private System.Windows.Forms.TextBox wejscie10;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.MaskedTextBox wejscie01;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox wejscie00;
        private System.Windows.Forms.MaskedTextBox BIAS;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.MaskedTextBox waga112;
        private System.Windows.Forms.MaskedTextBox waga110;
        private System.Windows.Forms.MaskedTextBox waga100;
        private System.Windows.Forms.MaskedTextBox waga102;
        private System.Windows.Forms.MaskedTextBox waga101;
        private System.Windows.Forms.MaskedTextBox waga111;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.MaskedTextBox waga212;
        private System.Windows.Forms.MaskedTextBox waga210;
        private System.Windows.Forms.MaskedTextBox waga200;
        private System.Windows.Forms.MaskedTextBox waga202;
        private System.Windows.Forms.MaskedTextBox waga201;
        private System.Windows.Forms.MaskedTextBox waga211;
        private System.Windows.Forms.TextBox wyjscie10;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox wyjscie21;
        private System.Windows.Forms.TextBox wejscie21;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox wyjscie20;
        private System.Windows.Forms.TextBox wejscie20;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox wyjscie11;
        private System.Windows.Forms.TextBox wejscie11;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox wyjscie23;
        private System.Windows.Forms.TextBox wyjscie22;
    }
}

